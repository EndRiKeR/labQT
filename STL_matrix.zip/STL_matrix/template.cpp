#include <matrix.h>
#include <matrix.cpp>

//template class MyMatrix<int>;

//template std::ostream& operator << <int>(std::ostream& out, MyMatrix<int>& matrix);
//template std::ostream& operator << <double>(std::ostream& out, MyMatrix<double>& matrix);
